/**
 * Main Client Logic & WebSocket State Synchronizer
 */

// Global State
let socket = null;
let currentRoom = null;
let selfPlayer = null;
let allPlayers = [];
let roomCode = null;
let playerId = null;
let playerName = null;
let hunterPinBuffer = "";
let countdownInterval = null;
let prevStatus = null;
let prevRadarPulse = false;
let isAudioMuted = false;

// Initialize when page loads
window.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  roomCode = (params.get('room') || '').toUpperCase().trim();
  playerId = params.get('pid');
  playerName = params.get('name') || 'Operator';

  if (!roomCode || !playerId) {
    alert("Missing room code or player ID! Redirecting to lobby...");
    window.location.href = '/';
    return;
  }

  document.getElementById('roomCodeDisplay').innerText = `ROOM: ${roomCode}`;
  document.getElementById('lobbyRoomBig').innerText = roomCode;

  // Initialize Map
  tacticalRadar.init('campusMap');
  tacticalRadar.onLocationChange = (lat, lng) => {
    sendWs({
      type: 'UPDATE_LOCATION',
      lat: lat,
      lng: lng
    });
  };

  // Connect WebSocket
  connectWebSocket();
});

// ----------------- WebSocket Connection -----------------

function connectWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const wsUrl = `${protocol}//${window.location.host}/ws/${roomCode}/${playerId}`;

  socket = new WebSocket(wsUrl);

  socket.onopen = () => {
    console.log("Tactical Uplink Established.");
  };

  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      handleServerMessage(data);
    } catch (e) {
      console.error("Malformed packet:", e);
    }
  };

  socket.onclose = () => {
    console.warn("Uplink Lost. Reconnecting in 2s...");
    setTimeout(connectWebSocket, 2000);
  };

  socket.onerror = (err) => {
    console.warn("WebSocket error:", err);
  };
}

function sendWs(payload) {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify(payload));
  }
}

// ----------------- Message Dispatcher -----------------

function handleServerMessage(data) {
  if (data.type === 'ERROR') {
    alert(data.message);
    return;
  }

  if (data.type === 'TAG_ERROR') {
    soundEngine.playCountdownBeep(true);
    alert(data.message);
    hunterPinBuffer = "";
    updateHunterPinScreen();
    return;
  }

  if (data.type === 'HOST_BROADCAST') {
    showHostAlert(data.event_data?.alert_text || "HOSTEL ALERT");
    soundEngine.playAlarmSiren();
    return;
  }

  if (data.type === 'TRIGGER_LOUD_SIREN') {
    soundEngine.playAlarmSiren();
    if (navigator.vibrate) navigator.vibrate([400, 100, 400, 100, 400]);
    alert("🚨 WARDEN PING: Your hiding spot is being pinged!");
    return;
  }

  if (data.type === 'ZONE_SHRUNK') {
    soundEngine.playAlarmSiren();
    return;
  }

  if (data.type === 'RUNNER_OUT_OF_BOUNDS') {
    soundEngine.playHeartbeat();
    return;
  }

  if (data.type === 'RADIO_MESSAGE' && data.chat) {
    appendRadioMessage(data.chat);
    soundEngine.playClick();
    return;
  }

  // State update packet
  if (data.room && data.self) {
    const wasAlive = selfPlayer ? selfPlayer.is_alive : true;
    const wasRunner = selfPlayer ? selfPlayer.role === 'RUNNER' : true;

    currentRoom = data.room;
    selfPlayer = data.self;
    allPlayers = data.players || [];

    // Check if YOU were just infected!
    if (wasRunner && selfPlayer.role === 'HUNTER' && currentRoom.status === 'ACTIVE') {
      triggerInfectionAlert(selfPlayer.tagged_by || "A Hunter");
    }

    renderGameState(data);
  }
}

// ----------------- Render Game State -----------------

function renderGameState(data) {
  const room = currentRoom;
  const me = selfPlayer;

  // 1. Update HUD theme and badges
  const isHunter = me.role === 'HUNTER';
  document.body.classList.toggle('mode-hunter', isHunter);

  const roleBadge = document.getElementById('roleBadge');
  const roleAvatar = document.getElementById('roleAvatar');
  roleAvatar.innerText = me.avatar || (isHunter ? '💀' : '🏃');

  if (isHunter) {
    roleBadge.className = 'badge badge-red';
    roleBadge.innerText = 'HUNTER';
    document.getElementById('hudTitle').innerText = 'MANHUNT // PREDATOR';
  } else {
    roleBadge.className = 'badge badge-cyan';
    roleBadge.innerText = 'RUNNER';
    document.getElementById('hudTitle').innerText = 'MANHUNT // STEALTH';
  }

  // 2. Switch Views based on Room Status
  const vLobby = document.getElementById('viewLobby');
  const vHeadstart = document.getElementById('viewHeadStart');
  const vActive = document.getElementById('viewActive');
  const vGameOver = document.getElementById('viewGameOver');

  vLobby.style.display = room.status === 'LOBBY' ? 'block' : 'none';
  vHeadstart.style.display = room.status === 'HEAD_START' ? 'block' : 'none';
  vActive.style.display = room.status === 'ACTIVE' ? 'block' : 'none';
  vGameOver.style.display = room.status === 'ENDED' ? 'block' : 'none';

  // Audio & Phase Transition Events
  if (prevStatus !== room.status) {
    if (room.status === 'HEAD_START') {
      soundEngine.playAlarmSiren();
    } else if (room.status === 'ACTIVE') {
      soundEngine.playAlarmSiren();
    } else if (room.status === 'ENDED') {
      soundEngine.playVictoryChime();
    }
    prevStatus = room.status;
  }

  // 3. Render according to view
  if (room.status === 'LOBBY') {
    renderLobby(room, me, allPlayers);
  } else if (room.status === 'HEAD_START') {
    renderHeadStart(room, me);
  } else if (room.status === 'ACTIVE') {
    renderActiveHunt(room, me, allPlayers);
  } else if (room.status === 'ENDED') {
    renderGameOver(room, me, allPlayers);
  }

  // Render Kill Feed & Alerts
  renderKillFeed(data.kill_log || []);

  // Update Safe Zones & Map Radar
  tacticalRadar.updateSafeZones(room.safe_zones || []);
  if (room.playzone) {
    tacticalRadar.updatePlayzone(room.playzone);
  }
  tacticalRadar.renderTacticalRadar(allPlayers, me, room.radar_pulse_active);
}

// ----------------- Lobby Rendering -----------------

function renderLobby(room, me, players) {
  document.getElementById('playerCount').innerText = players.length;
  const isHost = me.id === room.host_id;
  document.getElementById('hostLobbyControls').style.display = isHost ? 'block' : 'none';
  document.getElementById('lobbyWaitingMsg').innerText = isHost 
    ? "You are the Commander. When everyone is ready, launch the hunt!" 
    : "Waiting for Commander to launch the hunt...";

  const rosterEl = document.getElementById('lobbyRosterGrid');
  rosterEl.innerHTML = "";

  players.forEach(p => {
    const card = document.createElement('div');
    const isP_Hunter = p.role === 'HUNTER';
    card.className = `roster-card ${isP_Hunter ? 'hunter' : 'runner'}`;
    
    card.innerHTML = `
      <div style="font-size:22px;">${p.avatar || '👤'}</div>
      <div style="overflow:hidden; flex:1;">
        <div style="font-size:0.85rem; font-weight:bold; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;">
          ${p.name} ${p.id === room.host_id ? '👑' : ''} ${p.id === me.id ? '<span style="color:var(--accent-cyan);">(You)</span>' : ''}
        </div>
        <div style="font-size:0.7rem; color:var(--text-dim); font-family:var(--font-mono);">${p.sector || 'Camp'}</div>
      </div>
      <div>
        <span class="badge ${isP_Hunter ? 'badge-red' : 'badge-cyan'}" style="font-size:0.65rem; cursor:pointer;" onclick="${isHost ? `switchPlayerRole('${p.id}', '${isP_Hunter ? 'RUNNER' : 'HUNTER'}')` : ''}">
          ${isP_Hunter ? 'HUNTER' : 'RUNNER'}
        </span>
      </div>
    `;
    rosterEl.appendChild(card);
  });
}

function switchPlayerRole(targetPid, newRole) {
  sendWs({
    type: 'SET_ROLE',
    target_player_id: targetPid,
    role: newRole
  });
}

function launchGame() {
  soundEngine.init();
  sendWs({ type: 'START_GAME' });
}

// ----------------- Head Start Rendering -----------------

function renderHeadStart(room, me) {
  const remaining = room.headstart_remaining || 0;
  const mins = Math.floor(remaining / 60);
  const secs = remaining % 60;
  const timerStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  document.getElementById('headstartTimerBig').innerText = timerStr;

  const isHunter = me.role === 'HUNTER';
  const msgEl = document.getElementById('headstartMessage');
  const card = document.getElementById('headstartCard');
  const runnerPinBox = document.getElementById('headstartRunnerPinBox');

  if (isHunter) {
    card.style.borderColor = 'var(--accent-red)';
    card.style.boxShadow = 'var(--shadow-glow-red)';
    msgEl.innerHTML = `<b style="color:var(--accent-red);">PREDATOR LOCKDOWN:</b> You are blinded. Runners are scattering. Prepare to hunt!`;
    runnerPinBox.style.display = 'none';
  } else {
    card.style.borderColor = 'var(--accent-cyan)';
    card.style.boxShadow = 'var(--shadow-glow-cyan)';
    msgEl.innerHTML = `<b style="color:var(--accent-cyan);">SPRINT!</b> Find a hiding spot or secure sector before hunters release!`;
    runnerPinBox.style.display = 'block';
    if (me.pin) {
      document.getElementById('headstartPinDigits').innerText = me.pin;
    }
  }

  // Periodic beeps during last 5 seconds
  if (remaining <= 5 && remaining > 0) {
    soundEngine.playCountdownBeep(remaining === 1);
  }
}

// ----------------- Active Hunt Rendering -----------------

function renderActiveHunt(room, me, players) {
  // Timers
  const gameRem = room.game_remaining || 0;
  const gMins = Math.floor(gameRem / 60);
  const gSecs = gameRem % 60;
  document.getElementById('gameTimer').innerText = `${String(gMins).padStart(2, '0')}:${String(gSecs).padStart(2, '0')}`;

  // Tickers
  document.getElementById('runnersCountDisplay').innerText = room.runners_count;
  document.getElementById('huntersCountDisplay').innerText = room.hunters_count;

  // Shrinking Playzone Telemetry
  if (room.playzone && room.playzone.current_radius) {
    document.getElementById('playzoneDisplay').innerText = `${Math.round(room.playzone.current_radius)}m`;
  }

  // Out of Bounds Zone Alert for Runners
  const zoneBanner = document.getElementById('zoneWarningBanner');
  if (zoneBanner) {
    if (me.role === 'RUNNER' && me.is_outside_zone) {
      zoneBanner.style.display = 'block';
    } else {
      zoneBanner.style.display = 'none';
    }
  }

  // Radar Pulse Banner
  const radarBanner = document.getElementById('radarPulseBanner');
  const radarText = document.getElementById('radarPulseText');
  const radarBadge = document.getElementById('radarPulseBadge');

  if (room.radar_pulse_active) {
    radarBanner.className = 'radar-pulse-bar active';
    radarBadge.className = 'badge badge-red';
    radarBadge.innerText = 'EXPOSED';
    radarText.innerText = `🚨 SATELLITE RECON ACTIVE (${room.radar_pulse_remaining}s)!`;

    // Sound effect on radar activation transition
    if (!prevRadarPulse) {
      soundEngine.playRadarPing();
      prevRadarPulse = true;
    }
  } else {
    radarBanner.className = 'radar-pulse-bar';
    radarBadge.className = 'badge badge-amber';
    radarBadge.innerText = 'PASSIVE';
    const nextIn = room.next_radar_in || 0;
    const rMins = Math.floor(nextIn / 60);
    const rSecs = nextIn % 60;
    radarText.innerText = `📡 NEXT SATELLITE SWEEP IN: ${String(rMins).padStart(2, '0')}:${String(rSecs).padStart(2, '0')}`;
    prevRadarPulse = false;
  }

  // Role HUD switcher
  const isHunter = me.role === 'HUNTER';
  document.getElementById('runnerHudBox').style.display = !isHunter ? 'block' : 'none';
  document.getElementById('hunterHudBox').style.display = isHunter ? 'block' : 'none';

  // Adapt Radio UI to current role
  const radioTitle = document.getElementById('radioTitleText');
  const radioBtn = document.getElementById('btnSendRadio');
  const radioCard = document.getElementById('radioCardBox');
  if (isHunter) {
    radioTitle.innerText = '💀 PREDATOR RADIO (HUNTERS ONLY)';
    radioTitle.style.color = 'var(--accent-red)';
    radioBtn.className = 'btn btn-red btn-sm';
    radioCard.style.borderColor = 'rgba(255, 42, 95, 0.4)';
  } else {
    radioTitle.innerText = '📻 SQUAD RADIO (RUNNERS ONLY)';
    radioTitle.style.color = 'var(--accent-cyan)';
    radioBtn.className = 'btn btn-cyan btn-sm';
    radioCard.style.borderColor = 'rgba(0, 242, 254, 0.3)';
  }

  if (!isHunter && me.pin) {
    document.getElementById('mySecretPin').innerText = me.pin;
    document.getElementById('runnerBigPinDisplay').innerText = me.pin;
  }

  // Pending Claim Alert for Runner (Auto-confirm countdown)
  const incomingClaimModal = document.getElementById('incomingClaimModal');
  if (incomingClaimModal) {
    if (me.role === 'RUNNER' && me.pending_claim) {
      incomingClaimModal.style.display = 'flex';
      document.getElementById('claimingHunterName').innerText = me.pending_claim.hunter_name || 'A Hunter';
      const rem = Math.max(0, Math.round((me.pending_claim.expires_at || 0) - Date.now() / 1000));
      document.getElementById('claimCountdownSeconds').innerText = rem;
      soundEngine.playHeartbeat();
    } else {
      incomingClaimModal.style.display = 'none';
    }
  }

  // Host Controls
  const isHost = me.id === room.host_id;
  document.getElementById('hostInGameBar').style.display = isHost ? 'block' : 'none';
  if (isHost) {
    renderHostWardenControls(room, players);
  }
}

// ----------------- Game Over Rendering -----------------

function renderGameOver(room, me, players) {
  const title = document.getElementById('victoryWinnerTitle');
  const subtitle = document.getElementById('victorySubtitle');
  const card = document.getElementById('victoryHeroCard');

  if (room.winner === 'HUNTERS') {
    card.style.borderColor = 'var(--accent-red)';
    card.style.boxShadow = 'var(--shadow-glow-red)';
    title.innerText = 'HUNTERS WIN';
    title.style.color = 'var(--accent-red)';
    subtitle.innerText = 'The campus was fully infected! All targets eliminated.';
  } else {
    card.style.borderColor = 'var(--accent-cyan)';
    card.style.boxShadow = 'var(--shadow-glow-cyan)';
    title.innerText = 'SURVIVORS WIN';
    title.style.color = 'var(--accent-cyan)';
    subtitle.innerText = `${room.runners_count} runner(s) successfully evaded the predators!`;
  }

  // Compute Highlights
  let topHunter = null;
  let maxKills = -1;
  let survivors = [];

  players.forEach(p => {
    if (p.kills_count > maxKills) {
      maxKills = p.kills_count;
      topHunter = p;
    }
    if (p.role === 'RUNNER' && p.is_alive) {
      survivors.push(p);
    }
  });

  if (topHunter && maxKills > 0) {
    document.getElementById('mvpHunterName').innerText = `${topHunter.avatar || ''} ${topHunter.name}`;
    document.getElementById('mvpHunterTags').innerText = `${maxKills} TAGS`;
  } else {
    document.getElementById('mvpHunterName').innerText = 'None';
    document.getElementById('mvpHunterTags').innerText = '0 TAGS';
  }

  if (survivors.length > 0) {
    document.getElementById('mvpRunnerName').innerText = survivors.map(s => s.name).join(', ');
    document.getElementById('mvpRunnerStatus').innerText = 'SURVIVED';
  } else {
    document.getElementById('mvpRunnerName').innerText = 'None (All Infected)';
    document.getElementById('mvpRunnerStatus').innerText = 'ELIMINATED';
  }

  const isHost = me.id === room.host_id;
  document.getElementById('hostResetBox').style.display = isHost ? 'block' : 'none';
}

// ----------------- Hunter Elimination Numpad -----------------

function pressKey(char) {
  soundEngine.playClick();
  if (char === 'C') {
    hunterPinBuffer = hunterPinBuffer.slice(0, -1);
  } else {
    if (hunterPinBuffer.length < 4) {
      hunterPinBuffer += char;
    }
  }
  updateHunterPinScreen();
}

function updateHunterPinScreen() {
  const display = document.getElementById('hunterPinInput');
  if (hunterPinBuffer.length === 0) {
    display.innerText = "____";
  } else {
    display.innerText = hunterPinBuffer.padEnd(4, '_');
  }
}

function submitHunterPin() {
  if (hunterPinBuffer.length !== 4) {
    alert("Enter complete 4-digit code from the runner!");
    return;
  }

  soundEngine.playClick();
  sendWs({
    type: 'TAG_PIN',
    pin: hunterPinBuffer
  });

  hunterPinBuffer = "";
  updateHunterPinScreen();
}

// ----------------- QR Code Scanner for Hunter -----------------

function openCameraScanner() {
  document.getElementById('cameraScannerModal').style.display = 'flex';
  qrHelper.startScanner(
    'qrScannerReader',
    (decodedText) => {
      // Runner scanned!
      document.getElementById('cameraScannerModal').style.display = 'none';
      soundEngine.playEliminationSting();
      // Send the scanned text/PIN
      const pin = decodedText.trim();
      sendWs({
        type: 'TAG_PIN',
        pin: pin
      });
    },
    (err) => {
      document.getElementById('cameraScannerModal').style.display = 'none';
    }
  );
}

function closeCameraScanner() {
  qrHelper.stopScanner();
  document.getElementById('cameraScannerModal').style.display = 'none';
}

// ----------------- Runner QR Code Display -----------------

function showRunnerQrModal() {
  if (!selfPlayer || !selfPlayer.pin) return;
  document.getElementById('runnerQrModal').style.display = 'flex';
  qrHelper.renderQR('runnerQrCodeArea', selfPlayer.pin, 200);
}

function closeRunnerQrModal() {
  document.getElementById('runnerQrModal').style.display = 'none';
}

// ----------------- Runner Surrender -----------------

function showSurrenderModal() {
  const select = document.getElementById('surrenderHunterSelect');
  select.innerHTML = "";
  
  const hunters = allPlayers.filter(p => p.role === 'HUNTER');
  if (hunters.length === 0) {
    select.innerHTML = `<option value="Hunter">A Hunter</option>`;
  } else {
    hunters.forEach(h => {
      const opt = document.createElement('option');
      opt.value = h.name;
      opt.innerText = `${h.avatar || ''} ${h.name} (${h.sector || 'Camp'})`;
      select.appendChild(opt);
    });
  }

  document.getElementById('surrenderModal').style.display = 'flex';
}

function closeSurrenderModal() {
  document.getElementById('surrenderModal').style.display = 'none';
}

function confirmSurrender() {
  const hunterName = document.getElementById('surrenderHunterSelect').value;
  sendWs({
    type: 'RUNNER_SURRENDER',
    hunter_name: hunterName
  });
  closeSurrenderModal();
}

// ----------------- Infection Alert Overlay -----------------

function triggerInfectionAlert(hunterName) {
  soundEngine.playEliminationSting();
  document.getElementById('infectorNameDisplay').innerText = hunterName;
  document.getElementById('infectedFlashOverlay').style.display = 'flex';
}

function dismissInfectionBanner() {
  document.getElementById('infectedFlashOverlay').style.display = 'none';
}

// ----------------- Host Controls -----------------

function sendHostAlert() {
  const input = document.getElementById('hostAlertInput');
  const text = input.value.trim();
  if (text) {
    sendWs({
      type: 'BROADCAST_ALERT',
      message: text
    });
    input.value = "";
  }
}

function showHostAlert(msg) {
  const bar = document.getElementById('hostAlertBar');
  bar.innerText = `📢 BROADCAST: ${msg}`;
  bar.style.display = 'block';
  setTimeout(() => {
    bar.style.display = 'none';
  }, 10000);
}

function triggerManualRadar() {
  sendWs({ type: 'TRIGGER_RADAR' });
}

function resetToLobby() {
  sendWs({ type: 'RESET_GAME' });
}

// ----------------- Sector Update -----------------

function updateMySector(sectorName, el) {
  soundEngine.playClick();
  document.querySelectorAll('#activeSectorPills .sector-pill').forEach(p => p.classList.remove('active'));
  if (el) el.classList.add('active');

  sendWs({
    type: 'UPDATE_LOCATION',
    sector: sectorName
  });
}

// ----------------- Anti-Cheat & Direct Claim System -----------------

function computeDistanceMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

function openClaimTagModal() {
  const modal = document.getElementById('claimTagModal');
  const list = document.getElementById('claimTagRunnerList');
  list.innerHTML = "";

  // ANTI-CHEAT FILTER: Only runners physically within touching distance (<20m or same sector)
  const nearbyRunners = allPlayers.filter(p => {
    if (p.role !== 'RUNNER' || !p.is_alive) return false;

    if (selfPlayer.lat && selfPlayer.lng && p.lat && p.lng) {
      const d = computeDistanceMeters(selfPlayer.lat, selfPlayer.lng, p.lat, p.lng);
      p._dist = Math.round(d);
      return d <= 20; // 20-meter physical lock
    }

    // Sector match for indoor play
    if (selfPlayer.sector && p.sector) {
      return selfPlayer.sector.trim().toLowerCase() === p.sector.trim().toLowerCase();
    }
    return false;
  });

  if (nearbyRunners.length === 0) {
    list.innerHTML = `
      <div style="font-size:0.8rem; color:var(--accent-red); text-align:center; padding:16px 10px; background:rgba(255,42,95,0.08); border-radius:10px; border:1px dashed var(--accent-red); line-height:1.5;">
        ❌ <b>NO RUNNERS WITHIN TOUCHING DISTANCE (<20m)</b><br>
        <span style="font-size:0.75rem; color:var(--text-dim);">Anti-Cheat Lockout: You cannot claim tags from across campus. You must be in the same room/sector or within 20m of the target!</span>
      </div>
    `;
  } else {
    nearbyRunners.forEach(r => {
      const item = document.createElement('div');
      item.style.display = 'flex';
      item.style.justifyContent = 'space-between';
      item.style.alignItems = 'center';
      item.style.padding = '8px 10px';
      item.style.background = 'rgba(255,255,255,0.04)';
      item.style.borderRadius = '8px';
      item.style.marginBottom = '6px';

      const distText = r._dist !== undefined ? `${r._dist}m away` : `Same Sector (${r.sector})`;

      item.innerHTML = `
        <div>
          <b style="color:var(--accent-cyan); font-size:0.9rem;">${r.avatar || ''} ${r.name}</b>
          <div style="font-size:0.7rem; color:var(--accent-green); font-family:var(--font-mono);">PROXIMITY CONFIRMED: ${distText}</div>
        </div>
        <button class="btn btn-red btn-sm" onclick="submitClaimTag('${r.id}')">CLAIM TAG</button>
      `;
      list.appendChild(item);
    });
  }

  modal.style.display = 'flex';
}

function closeClaimTagModal() {
  document.getElementById('claimTagModal').style.display = 'none';
}

function submitClaimTag(runnerId) {
  closeClaimTagModal();
  soundEngine.playClick();
  sendWs({
    type: 'CLAIM_TAG',
    target_player_id: runnerId
  });
}

function acceptTagClaim() {
  soundEngine.playClick();
  sendWs({ type: 'ACCEPT_TAG_CLAIM' });
  const modal = document.getElementById('incomingClaimModal');
  if (modal) modal.style.display = 'none';
}

function disputeTagClaim() {
  const reason = prompt("Enter brief reason for dispute (e.g., 'They touched someone else / were in safe zone'):") || "Disputed tag physical touch";
  sendWs({
    type: 'DISPUTE_TAG_CLAIM',
    reason: reason
  });
  const modal = document.getElementById('incomingClaimModal');
  if (modal) modal.style.display = 'none';
  alert("⚖️ Dispute transmitted to Warden/Host! Awaiting official ruling.");
}

// ----------------- Host Warden Oversight Controls -----------------

function renderHostWardenControls(room, players) {
  // 1. Render active disputes
  const dispList = document.getElementById('hostDisputesList');
  if (dispList) {
    const activeDisputes = room.disputes || [];
    if (activeDisputes.length === 0) {
      dispList.innerHTML = `<div style="font-size:0.75rem; color:var(--text-dim); font-style:italic;">No active disputes. Clean match!</div>`;
    } else {
      dispList.innerHTML = "";
      activeDisputes.forEach(d => {
        const div = document.createElement('div');
        div.style.padding = '8px';
        div.style.background = 'rgba(255,42,95,0.15)';
        div.style.border = '1px solid var(--accent-red)';
        div.style.borderRadius = '8px';
        div.style.marginBottom = '6px';
        div.innerHTML = `
          <div style="font-size:0.8rem; font-weight:bold; color:#fff; margin-bottom:4px;">
            ⚖️ ${d.runner_name} disputes tag by ${d.hunter_name}
          </div>
          <div style="font-size:0.75rem; color:var(--text-dim); margin-bottom:6px;">
            Reason: "${d.reason || 'No reason'}" [${d.time}]
          </div>
          <div style="display:flex; gap:6px;">
            <button class="btn btn-red btn-sm" onclick="hostResolveDispute('${d.id}', 'INFECT')">✓ TAG VALID (INFECT)</button>
            <button class="btn btn-outline btn-sm" onclick="hostResolveDispute('${d.id}', 'DISMISS')">❌ DISMISS</button>
          </div>
        `;
        dispList.appendChild(div);
      });
    }
  }

  // 2. Render runners with Warden Force-Infect and Siren Ping
  const ctrlList = document.getElementById('hostRunnersControlList');
  if (ctrlList) {
    ctrlList.innerHTML = "";
    const runners = players.filter(p => p.role === 'RUNNER' && p.is_alive);
    if (runners.length === 0) {
      ctrlList.innerHTML = `<div style="font-size:0.75rem; color:var(--text-dim); font-style:italic;">All runners infected!</div>`;
    } else {
      runners.forEach(r => {
        const row = document.createElement('div');
        row.style.display = 'flex';
        row.style.justifyContent = 'space-between';
        row.style.alignItems = 'center';
        row.style.padding = '6px 8px';
        row.style.background = 'rgba(255,255,255,0.03)';
        row.style.borderRadius = '6px';
        row.style.marginBottom = '4px';

        row.innerHTML = `
          <div style="overflow:hidden; margin-right:6px;">
            <b style="color:var(--accent-cyan); font-size:0.8rem;">${r.name}</b>
            <span style="font-size:0.7rem; color:${r.is_connected ? 'var(--accent-green)' : 'var(--accent-red)'}; font-family:var(--font-mono);">
              ${r.is_connected ? '● ON' : '○ OFF'}
            </span>
          </div>
          <div style="display:flex; gap:4px;">
            <button class="btn btn-outline btn-sm" title="Sound loud alarm on their phone" onclick="hostPingSiren('${r.id}')" style="padding:4px 8px; font-size:0.7rem;">🔊 PING</button>
            <button class="btn btn-red btn-sm" title="Force convert to Hunter" onclick="hostForceInfect('${r.id}')" style="padding:4px 8px; font-size:0.7rem;">⚡ FORCE</button>
          </div>
        `;
        ctrlList.appendChild(row);
      });
    }
  }
}

function hostResolveDispute(disputeId, verdict) {
  sendWs({
    type: 'RESOLVE_DISPUTE',
    dispute_id: disputeId,
    verdict: verdict
  });
}

function hostForceInfect(pid) {
  if (confirm("Force this runner to be infected?")) {
    sendWs({
      type: 'FORCE_INFECT',
      target_player_id: pid
    });
  }
}

function hostPingSiren(pid) {
  sendWs({
    type: 'FORCE_SIREN_PING',
    target_player_id: pid
  });
  alert("Siren broadcast sent to player's device!");
}

// ----------------- Squad Radio Comms -----------------

function sendRadioMsg() {
  const input = document.getElementById('radioInputText');
  const text = input.value.trim();
  if (!text) return;
  sendWs({
    type: 'SEND_RADIO_CHAT',
    message: text
  });
  input.value = "";
}

function sendQuickRadio(quickText) {
  sendWs({
    type: 'SEND_RADIO_CHAT',
    message: quickText
  });
}

function appendRadioMessage(chat) {
  const list = document.getElementById('radioMsgList');
  if (!list) return;

  const isSelf = selfPlayer && selfPlayer.name === chat.sender;
  const isHunter = chat.role === 'HUNTER';
  const bubble = document.createElement('div');
  bubble.className = `feed-item ${isHunter ? 'tag' : ''}`;
  bubble.style.borderLeftColor = isHunter ? 'var(--accent-red)' : 'var(--accent-cyan)';

  bubble.innerHTML = `
    <div style="display:flex; justify-content:space-between; margin-bottom:2px;">
      <b style="color:${isHunter ? 'var(--accent-red)' : 'var(--accent-cyan)'};">
        ${chat.avatar || ''} ${chat.sender} ${isSelf ? '(You)' : ''} [${chat.sector || 'Field'}]
      </b>
      <span style="color:var(--text-dim); font-size:0.7rem;">${chat.time}</span>
    </div>
    <div style="color:#fff; font-size:0.85rem;">${chat.text}</div>
  `;

  list.appendChild(bubble);
  list.scrollTop = list.scrollHeight;
}

// ----------------- Kill Feed Rendering -----------------

function renderKillFeed(feedItems) {
  const feedEl = document.getElementById('killFeedList');
  if (!feedEl) return;
  feedEl.innerHTML = "";

  feedItems.slice().reverse().forEach(item => {
    const div = document.createElement('div');
    div.className = `feed-item ${item.type === 'TAG' ? 'tag' : item.type === 'RADAR' ? 'radar' : item.type === 'HOST_ALERT' ? 'alert' : ''}`;
    div.innerHTML = `<span style="color:var(--text-dim); margin-right:6px;">[${item.time}]</span> ${item.message}`;
    feedEl.appendChild(div);
  });
}

// ----------------- Utilities -----------------

function copyJoinLink() {
  const url = `${window.location.origin}/game?room=${roomCode}`;
  navigator.clipboard.writeText(url).then(() => {
    alert("Join Link copied to clipboard! Send it to your hostel WhatsApp group!");
  }).catch(() => {
    prompt("Copy this join link:", url);
  });
}

function toggleLobbyQr() {
  const container = document.getElementById('lobbyQrContainer');
  if (container.style.display === 'none') {
    container.style.display = 'block';
    const url = `${window.location.origin}/game?room=${roomCode}`;
    qrHelper.renderQR('lobbyQrContainer', url, 180);
  } else {
    container.style.display = 'none';
  }
}

function toggleMuteAudio() {
  isAudioMuted = soundEngine.toggleMute();
  document.getElementById('btnAudioToggle').innerText = isAudioMuted ? '🔇' : '🔊';
}
