/**
 * Tactical Web Audio API Sound Synthesizer
 * Zero external audio assets required. Runs completely client-side.
 */

class TacticalAudio {
  constructor() {
    this.ctx = null;
    this.muted = false;
  }

  init() {
    if (!this.ctx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AudioContext();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.muted = !this.muted;
    return this.muted;
  }

  // --- 1. Tactical Sonar Radar Ping ---
  playRadarPing() {
    if (this.muted) return;
    this.init();
    const t = this.ctx.currentTime;
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1400, t);
    osc.frequency.exponentialRampToValueAtTime(700, t + 0.45);

    gain.gain.setValueAtTime(0.35, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.8);

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + 0.85);

    // Trigger haptic pulse
    if (navigator.vibrate) {
      navigator.vibrate(80);
    }
  }

  // --- 2. Countdown Beep ---
  playCountdownBeep(isFinal = false) {
    if (this.muted) return;
    this.init();
    const t = this.ctx.currentTime;
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = isFinal ? 'sawtooth' : 'triangle';
    osc.frequency.setValueAtTime(isFinal ? 880 : 440, t);

    gain.gain.setValueAtTime(isFinal ? 0.4 : 0.25, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + (isFinal ? 0.5 : 0.15));

    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(t);
    osc.stop(t + (isFinal ? 0.5 : 0.15));

    if (navigator.vibrate) {
      navigator.vibrate(isFinal ? [100, 50, 200] : 40);
    }
  }

  // --- 3. Infection / Kill Sting ---
  playEliminationSting() {
    if (this.muted) return;
    this.init();
    const t = this.ctx.currentTime;

    // Sub-bass thump
    const sub = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(160, t);
    sub.frequency.exponentialRampToValueAtTime(35, t + 0.6);
    subGain.gain.setValueAtTime(0.7, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.7);
    sub.connect(subGain);
    subGain.connect(this.ctx.destination);
    sub.start(t);
    sub.stop(t + 0.7);

    // Harsh glitch screech
    const glitch = this.ctx.createOscillator();
    const glitchGain = this.ctx.createGain();
    glitch.type = 'sawtooth';
    glitch.frequency.setValueAtTime(320, t);
    glitch.frequency.linearRampToValueAtTime(110, t + 0.4);
    glitchGain.gain.setValueAtTime(0.4, t);
    glitchGain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
    glitch.connect(glitchGain);
    glitchGain.connect(this.ctx.destination);
    glitch.start(t);
    glitch.stop(t + 0.45);

    // Intense haptic pattern
    if (navigator.vibrate) {
      navigator.vibrate([200, 100, 300, 100, 500]);
    }
  }

  // --- 4. Red Alert Siren (Hunters Unleashed / Lockdown) ---
  playAlarmSiren() {
    if (this.muted) return;
    this.init();
    const t = this.ctx.currentTime;

    for (let i = 0; i < 3; i++) {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';

      const startTime = t + (i * 0.45);
      osc.frequency.setValueAtTime(600, startTime);
      osc.frequency.linearRampToValueAtTime(950, startTime + 0.22);
      osc.frequency.linearRampToValueAtTime(600, startTime + 0.44);

      gain.gain.setValueAtTime(0.3, startTime);
      gain.gain.exponentialRampToValueAtTime(0.01, startTime + 0.44);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.45);
    }

    if (navigator.vibrate) {
      navigator.vibrate([300, 150, 300, 150, 300]);
    }
  }

  // --- 5. Tense Heartbeat (Tension / Proximity) ---
  playHeartbeat() {
    if (this.muted) return;
    this.init();
    const t = this.ctx.currentTime;

    const hit = (time, freq, gainVal) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, time);
      osc.frequency.exponentialRampToValueAtTime(30, time + 0.12);
      gain.gain.setValueAtTime(gainVal, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + 0.15);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(time);
      osc.stop(time + 0.15);
    };

    hit(t, 90, 0.5);
    hit(t + 0.18, 75, 0.35);

    if (navigator.vibrate) {
      navigator.vibrate([60, 80, 50]);
    }
  }

  // --- 6. Victory Chime ---
  playVictoryChime() {
    if (this.muted) return;
    this.init();
    const t = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C E G C

    notes.forEach((freq, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + idx * 0.15);
      gain.gain.setValueAtTime(0.25, t + idx * 0.15);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.15 + 0.8);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(t + idx * 0.15);
      osc.stop(t + idx * 0.15 + 0.85);
    });
  }

  // --- 7. Subtle UI Click ---
  playClick() {
    if (this.muted) return;
    this.init();
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1000, t);
    gain.gain.setValueAtTime(0.1, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(t);
    osc.stop(t + 0.04);
  }
}

window.soundEngine = new TacticalAudio();
