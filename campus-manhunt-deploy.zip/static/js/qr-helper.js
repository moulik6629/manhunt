/**
 * QR Code Display & Scanner Helper
 */

class QRHelper {
  constructor() {
    this.scannerInstance = null;
    this.isScanning = false;
  }

  /**
   * Render QR code using QRCode library into a container element
   */
  renderQR(containerId, text, size = 180) {
    const el = document.getElementById(containerId);
    if (!el) return;
    el.innerHTML = "";
    if (typeof QRCode !== "undefined") {
      new QRCode(el, {
        text: text,
        width: size,
        height: size,
        colorDark: "#ffffff",
        colorLight: "#080c10",
        correctLevel: QRCode.CorrectLevel.M
      });
    } else {
      // Fallback if offline/CDN unavailable: generate SVG data QR or text display
      el.innerHTML = `<div style="font-family:monospace;font-size:1.4rem;padding:20px;border:2px dashed #00f2fe;color:#00f2fe;">CODE: ${text}</div>`;
    }
  }

  /**
   * Open Camera Scanner modal
   */
  async startScanner(elementId, onSuccess, onError) {
    if (typeof Html5Qrcode === "undefined") {
      alert("QR Scanner library loading or camera unavailable. Please type the 4-digit PIN!");
      if (onError) onError("Library missing");
      return;
    }

    try {
      this.scannerInstance = new Html5Qrcode(elementId);
      this.isScanning = true;

      const config = { fps: 10, qrbox: { width: 220, height: 220 } };

      await this.scannerInstance.start(
        { facingMode: "environment" },
        config,
        (decodedText) => {
          // Decoded QR successfully
          this.stopScanner();
          if (onSuccess) onSuccess(decodedText);
        },
        (errorMessage) => {
          // Scan frame miss (can ignore normal frame misses)
        }
      );
    } catch (err) {
      console.warn("Camera start failed:", err);
      this.isScanning = false;
      alert("Camera access was denied or not supported on this browser. Use manual 4-digit PIN keypad!");
      if (onError) onError(err);
    }
  }

  /**
   * Stop Camera Scanner
   */
  async stopScanner() {
    if (this.scannerInstance && this.isScanning) {
      try {
        await this.scannerInstance.stop();
        this.scannerInstance.clear();
      } catch (e) {
        console.warn("Scanner stop warning", e);
      }
      this.isScanning = false;
    }
  }
}

window.qrHelper = new QRHelper();
