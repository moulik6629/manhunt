/**
 * Tactical Map & GPS Radar Manager using Leaflet.js
 */

class TacticalRadar {
  constructor() {
    this.map = null;
    this.markers = {};
    this.safeZoneLayers = [];
    this.userLat = null;
    this.userLng = null;
    this.watchId = null;
    this.radarWaveCircle = null;
    this.zoneSafeCircle = null;
    this.zoneDangerRing = null;
    this.lastKnownRunnerBlips = {};
    this.onLocationChange = null;
  }

  init(containerId = "campusMap", initialLat = 22.5726, initialLng = 88.3639) {
    if (this.map) return;

    // Initialize Leaflet
    this.map = L.map(containerId, {
      zoomControl: false,
      attributionControl: false
    }).setView([initialLat, initialLng], 17);

    // Dark Matter Tactical Tiles
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 19,
      subdomains: 'abcd'
    }).addTo(this.map);

    // Zoom control in top right
    L.control.zoom({ position: 'topright' }).addTo(this.map);

    // Click map to manually set location (useful for indoor testing or hostel wings)
    this.map.on('click', (e) => {
      this.setUserLocation(e.latlng.lat, e.latlng.lng);
    });

    // Start auto GPS tracking
    this.startGpsTracking();
  }

  startGpsTracking() {
    if (!navigator.geolocation) {
      console.warn("Geolocation not supported by device.");
      return;
    }

    this.watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        this.setUserLocation(latitude, longitude);
      },
      (err) => {
        console.warn("GPS tracking warning:", err.message);
      },
      {
        enableHighAccuracy: true,
        maximumAge: 5000,
        timeout: 10000
      }
    );
  }

  setUserLocation(lat, lng) {
    this.userLat = lat;
    this.userLng = lng;

    if (this.map) {
      // Pan to user location if first time
      if (!this.hasCentered) {
        this.map.setView([lat, lng], 17);
        this.hasCentered = true;
      }
    }

    if (this.onLocationChange) {
      this.onLocationChange(lat, lng);
    }
  }

  centerOnUser() {
    if (this.map && this.userLat && this.userLng) {
      this.map.setView([this.userLat, this.userLng], 18);
    }
  }

  // --- Draw Shrinking Playzone (Battle Royale Circle) ---
  updatePlayzone(playzone) {
    if (!this.map || !playzone || !playzone.center_lat || !playzone.center_lng) return;

    const center = [playzone.center_lat, playzone.center_lng];
    const radius = Math.max(10, playzone.current_radius);

    if (this.zoneSafeCircle) {
      this.zoneSafeCircle.setLatLng(center);
      this.zoneSafeCircle.setRadius(radius);
    } else {
      this.zoneSafeCircle = L.circle(center, {
        radius: radius,
        color: '#00f2fe',
        fillColor: '#00f2fe',
        fillOpacity: 0.06,
        weight: 3,
        dashArray: '8, 8'
      }).addTo(this.map);
      this.zoneSafeCircle.bindTooltip(`🛡️ PLAYZONE (${Math.round(radius)}m)`, { permanent: false, direction: 'center' });
    }

    if (this.zoneDangerRing) {
      this.zoneDangerRing.setLatLng(center);
      this.zoneDangerRing.setRadius(radius + 200);
    } else {
      this.zoneDangerRing = L.circle(center, {
        radius: radius + 200,
        color: '#ff2a5f',
        fillColor: '#ff2a5f',
        fillOpacity: 0.1,
        weight: 1,
        dashArray: '4, 12'
      }).addTo(this.map);
    }
  }

  // --- Draw Safe Zones ---
  updateSafeZones(safeZones) {
    if (!this.map) return;
    this.safeZoneLayers.forEach(l => this.map.removeLayer(l));
    this.safeZoneLayers = [];

    safeZones.forEach(sz => {
      if (sz.lat && sz.lng) {
        const circle = L.circle([sz.lat, sz.lng], {
          radius: sz.radius || 25,
          color: '#00ff88',
          fillColor: '#00ff88',
          fillOpacity: 0.15,
          weight: 2,
          dashArray: '4, 8'
        }).addTo(this.map);

        circle.bindTooltip(`🛡️ ${sz.name}`, { permanent: true, direction: 'center', className: 'safe-zone-tooltip' });
        this.safeZoneLayers.push(circle);
      }
    });
  }

  // --- Render Players on Radar ---
  renderTacticalRadar(players, selfPlayer, pulseActive) {
    if (!this.map) return;

    const currentPids = new Set();

    players.forEach(p => {
      currentPids.add(p.id);
      const isSelf = p.id === selfPlayer.id;

      if (p.lat && p.lng) {
        let iconHtml = '';
        let markerColor = '#00f2fe';

        if (p.role === 'HUNTER') {
          markerColor = '#ff2a5f';
          iconHtml = `<div style="
            background:${markerColor};
            color:#fff;
            border:2px solid #fff;
            border-radius:50%;
            width:34px;height:34px;
            display:flex;align-items:center;justify-content:center;
            font-size:16px;
            box-shadow: 0 0 16px ${markerColor};
            animation: pulse-ring 2s infinite;
          ">${p.avatar || '💀'}</div>`;
        } else {
          // Runner
          if (p.is_outside_zone) {
            markerColor = '#ff0055';
            iconHtml = `<div style="
              background:#ff0055;
              color:#fff;
              border:2px solid #fff;
              border-radius:50%;
              width:36px;height:36px;
              display:flex;align-items:center;justify-content:center;
              font-size:16px;
              box-shadow: 0 0 20px #ff0055;
              animation: pulse-danger 0.6s infinite alternate;
            ">⚠️</div>`;
          } else {
            markerColor = '#00f2fe';
            iconHtml = `<div style="
              background:rgba(0,242,254,0.85);
              color:#031320;
              border:2px solid #fff;
              border-radius:50%;
              width:32px;height:32px;
              display:flex;align-items:center;justify-content:center;
              font-size:15px;
              box-shadow: 0 0 15px ${markerColor};
            ">${p.avatar || '🏃'}</div>`;
          }

          // Record last known location
          this.lastKnownRunnerBlips[p.id] = {
            lat: p.lat,
            lng: p.lng,
            name: p.name,
            avatar: p.avatar,
            time: Date.now()
          };
        }

        const customIcon = L.divIcon({
          className: 'tactical-marker',
          html: iconHtml,
          iconSize: [34, 34],
          iconAnchor: [17, 17]
        });

        if (this.markers[p.id]) {
          this.markers[p.id].setLatLng([p.lat, p.lng]);
          this.markers[p.id].setIcon(customIcon);
        } else {
          const m = L.marker([p.lat, p.lng], { icon: customIcon }).addTo(this.map);
          m.bindTooltip(`${isSelf ? '⭐ [YOU] ' : ''}${p.name} (${p.sector})`, {
            direction: 'top',
            offset: [0, -18]
          });
          this.markers[p.id] = m;
        }
      } else {
        // Location hidden due to fog of war
        if (this.markers[p.id]) {
          this.map.removeLayer(this.markers[p.id]);
          delete this.markers[p.id];
        }
      }
    });

    // Remove obsolete markers
    Object.keys(this.markers).forEach(pid => {
      if (!currentPids.has(pid)) {
        this.map.removeLayer(this.markers[pid]);
        delete this.markers[pid];
      }
    });

    // Radar Wave Animation
    if (pulseActive) {
      this.triggerRadarSweepAnimation();
    }
  }

  triggerRadarSweepAnimation() {
    if (!this.map || !this.userLat || !this.userLng) return;

    if (this.radarWaveCircle) {
      this.map.removeLayer(this.radarWaveCircle);
    }

    this.radarWaveCircle = L.circle([this.userLat, this.userLng], {
      radius: 10,
      color: '#ff2a5f',
      fillColor: '#ff2a5f',
      fillOpacity: 0.15,
      weight: 2
    }).addTo(this.map);

    let currentRadius = 10;
    const expandInterval = setInterval(() => {
      currentRadius += 15;
      if (this.radarWaveCircle && this.map.hasLayer(this.radarWaveCircle)) {
        this.radarWaveCircle.setRadius(currentRadius);
      }
      if (currentRadius > 400) {
        clearInterval(expandInterval);
        if (this.radarWaveCircle) {
          this.map.removeLayer(this.radarWaveCircle);
          this.radarWaveCircle = null;
        }
      }
    }, 50);
  }
}

window.tacticalRadar = new TacticalRadar();
